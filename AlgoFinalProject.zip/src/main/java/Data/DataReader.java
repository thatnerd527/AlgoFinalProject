package Data;

public class DataReader {
    public DataReader() {
        
    }
}
